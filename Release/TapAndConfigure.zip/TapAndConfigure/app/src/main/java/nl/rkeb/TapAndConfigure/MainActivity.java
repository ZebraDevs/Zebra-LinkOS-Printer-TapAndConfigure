package nl.rkeb.TapAndConfigure;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.zebra.TapAndConfigure.R;
import com.zebra.printconnectintentswrapper.PCPassthroughPrint;
import com.zebra.printconnectintentswrapper.PCPassthroughPrintSettings;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    private TextView et_results;
    private ScrollView sv_results;
    private String mStatus = "";

    private void askPermission(String permission,int requestCode) {
        if (ContextCompat.checkSelfPermission(this,permission)!= PackageManager.PERMISSION_GRANTED){
            // We Don't have permission
            ActivityCompat.requestPermissions(this,new String[]{permission},requestCode);

        }else {
            // We already have permission do what you want
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Permission Denied", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    private StringBuilder getFontFile(File sdcard, String fileName) {

        File file = new File(sdcard, fileName);
        StringBuilder fileData = new StringBuilder();

        // write the header and data to the printer
        fileData.append("! CISDFCRC16\r\n");
        fileData.append(String.format("%04d\r\n", 0));
        fileData.append(fileName + "\r\n");
        int size = (int) file.length();
        fileData.append(String.format("%08X\r\n", size));
        fileData.append(String.format("%04d\r\n", 0));  // checksum, 0000 => ignore checksum

        byte[] bytes = new byte[size];
        try {
            BufferedInputStream buf = new BufferedInputStream(new FileInputStream(file));
            buf.read(bytes, 0, bytes.length);
            buf.close();
            addLineToResults(getCurrentDateTime() + " - " + String.format("%d",bytes.length));

        } catch (IOException e) {
            addLineToResults(e.toString());
        }
        String str = new String(bytes, StandardCharsets.UTF_8);
        fileData.append(str);
//        fileData.append("\r\n");

        return fileData;
    }

    private StringBuilder getConfigFile(File sdcard, String fileName) {
        //Get the text file
        File file = new File(sdcard, fileName);
        StringBuilder fileData = new StringBuilder();

        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                fileData.append(line);
                fileData.append('\n');
            }
            br.close();
        } catch (IOException e) {

        }
        return fileData;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        askPermission(Manifest.permission.READ_EXTERNAL_STORAGE,1);
        askPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE,1);

        et_results = (TextView)findViewById(R.id.et_results);
        sv_results = (ScrollView)findViewById(R.id.sv_results);

        Button setup = findViewById(R.id.button);
        setup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //*Don't* hardcode "/sdcard"
                File sdcard = Environment.getExternalStorageDirectory();

                StringBuilder prnData = new StringBuilder();

//                prnData = getFontFile(sdcard,"Alvania.ttf");
//                addLineToResults("Sending font to printer.");

//                prnData.append(getConfigFile(sdcard, "config.txt"));
                prnData = getConfigFile(sdcard, "config.txt");
                addLineToResults("Sending config to printer.");

                if (prnData.length() > 0) {
                    PCPassthroughPrintSettings settings = new PCPassthroughPrintSettings();

                    settings.mPassthroughData = prnData.toString();
                    final PCPassthroughPrint passthroughPrint = new PCPassthroughPrint(MainActivity.this);
                    passthroughPrint.execute(settings, new PCPassthroughPrint.onPassthroughResult() {
                        @Override
                        public void success(PCPassthroughPrintSettings settings) {
                            Looper.prepare();
                            Toast.makeText(MainActivity.this, "Printer setup succeeded.", Toast.LENGTH_LONG).show();
                            addLineToResults(getCurrentDateTime() + " - " + "Printer setup succeeded.");
                        }

                        @Override
                        public void error(final String errorMessage, int resultCode, Bundle resultData, PCPassthroughPrintSettings settings) {
                            Looper.prepare();
                            Toast.makeText(MainActivity.this, "Printer setup error.\n" + errorMessage, Toast.LENGTH_LONG).show();
                            addLineToResults("Printer setup error.\n" + errorMessage);
                        }

                        @Override
                        public void timeOut(PCPassthroughPrintSettings settings) {
                            Looper.prepare();
                            Toast.makeText(MainActivity.this, "Printer setup timeout.", Toast.LENGTH_LONG).show();
                            addLineToResults("Printer setup timeout.");
                        }
                    });
                }
            }
        });


    }

    private String getCurrentDateTime() {

        SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy HHmmss", Locale.getDefault());
        String currentDateandTime = sdf.format(new Date());
        return currentDateandTime;
    }


    private void addLineToResults(final String lineToAdd)
    {
        mStatus += lineToAdd + "\n";
        updateAndScrollDownTextView();
    }

    private void updateAndScrollDownTextView()
    {
        MainActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                et_results.setText(mStatus);
                sv_results.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }
}
